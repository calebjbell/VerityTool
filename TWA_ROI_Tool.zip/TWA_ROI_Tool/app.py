from flask import Flask, render_template, request

app = Flask(__name__)

# Route for the landing page
@app.route('/')
def landing_page():
    return render_template('index.html')

# Route for the Tools Overview page
@app.route('/tools')
def tools_page():
    return render_template('tools.html')

# Route for the Allocation Calculator page (input)
@app.route('/allocation_calculator', methods=['GET', 'POST'])
def allocation_calculator():
    if request.method == 'POST':
        # Get the form data
        funds_available = request.form.get('funds_available', type=float)
        retirement_date = request.form.get('retirement_date', type=int)

        # Calculate years to retirement based on the current year
        current_year = 2024
        years_to_retirement = retirement_date - current_year

        # Smooth transition logic for allocation
        if years_to_retirement > 15:
            optimal_equity_allocation = 100
            optimal_non_equity_allocation = 0
        elif 10 <= years_to_retirement <= 15:
            optimal_equity_allocation = 100 - ((15 - years_to_retirement) * 4)
            optimal_non_equity_allocation = 100 - optimal_equity_allocation
        elif 5 <= years_to_retirement < 10:
            optimal_equity_allocation = 80 - ((10 - years_to_retirement) * 4)
            optimal_non_equity_allocation = 100 - optimal_equity_allocation
        else:
            optimal_equity_allocation = 60 - ((5 - years_to_retirement) * 4)
            optimal_non_equity_allocation = 100 - optimal_equity_allocation

        # Calculate the amount of funds in equities and non-equities
        equity_amount = funds_available * (optimal_equity_allocation / 100)
        non_equity_amount = funds_available * (optimal_non_equity_allocation / 100)

        # Pass the results to the template
        return render_template('allocation_results.html',
                               optimal_equity_allocation=optimal_equity_allocation,
                               optimal_non_equity_allocation=optimal_non_equity_allocation,
                               equity_amount=equity_amount,
                               non_equity_amount=non_equity_amount)

    return render_template('allocation_calculator.html')

# Route for the Allocation Calculator results page (output)
@app.route('/allocation_results')
def allocation_results():
    return render_template('allocation_results.html')


# Route for the TWA ROI Tool page (input)
@app.route('/twa_roi', methods=['GET', 'POST'])
def twa_roi():
    if request.method == 'POST':
        # Get form data
        current_funds = request.form.get('current_funds', type=float)
        current_equity_allocation = request.form.get('current_equity_allocation', type=float)
        current_non_equity_allocation = request.form.get('current_non_equity_allocation', type=float)
        target_equity_allocation = request.form.get('target_equity_allocation', type=float)
        target_non_equity_allocation = request.form.get('target_non_equity_allocation', type=float)
        years_to_retirement = request.form.get('years_to_retirement', type=float)

        # Check if the required data is available
        if None in (current_funds, current_equity_allocation, current_non_equity_allocation, target_equity_allocation, target_non_equity_allocation, years_to_retirement):
            return "Error: Missing form data", 400
        
        # Example ROI calculations (replace with your actual logic)
        current_growth = current_funds * (1 + (current_equity_allocation / 100) * 0.08 + (current_non_equity_allocation / 100) * 0.04) ** years_to_retirement
        target_growth = current_funds * (1 + (target_equity_allocation / 100) * 0.08 + (target_non_equity_allocation / 100) * 0.04) ** years_to_retirement
        roi = target_growth - current_growth
        
        # Render the results template with the calculated values
        return render_template('twa_roi_results.html', current_growth=current_growth, target_growth=target_growth, roi=roi)
    
    return render_template('twa_roi.html')

# Route for the TWA ROI results page (output)
@app.route('/twa_roi_results')
def twa_roi_results():
    return render_template('twa_roi_results.html')


if __name__ == '__main__':
    app.run(debug=True)
